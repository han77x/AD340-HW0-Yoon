package com.example.a009x.hw3;

import android.content.Intent;
import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.widget.TextView;


public class InfoActivity extends AppCompatActivity {



    private TextView title;
    private TextView url;
    private TextView year;
    private TextView description;
    private TextView name;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_info);

//        reference views
        title = findViewById(R.id.titleInfo);
        year = findViewById(R.id.yearInfo);
        name = findViewById(R.id.nameInfo);
        url = findViewById(R.id.urlInfo);
        description = findViewById(R.id.detailInfo);

//        set intent to views
        Intent intent = getIntent();
        String inTitle = intent.getStringExtra(RecyclerAdapter.TITLE);
        String inYear = intent.getStringExtra(RecyclerAdapter.YEAR);
        String inName = intent.getStringExtra(RecyclerAdapter.NAME);
        String inUrl = intent.getStringExtra(RecyclerAdapter.URL);
        String inDescription = intent.getStringExtra(RecyclerAdapter.DESCRIPTION);

        title.setText(inTitle);
        year.setText(inYear);
        name.setText(inName);
        url.setText(inUrl);
        description.setText(inDescription);


    }
}
