package com.example.a009x.hw6;

import android.content.Context;
import android.support.annotation.Nullable;
import android.support.v4.content.AsyncTaskLoader;

public class AsyncTask extends AsyncTaskLoader<String> {

    public AsyncTask(Context context) {
        super(context);

    }

    @Nullable
    @Override
    public String loadInBackground() {

        String url = "https://web6.seattle.gov/Travelers/api/Map/Data?zoomId=13&type=2";

        return NetworkConnection.getData(url);
    }

    @Override
    protected void onStartLoading() {
        forceLoad();
    }
}
