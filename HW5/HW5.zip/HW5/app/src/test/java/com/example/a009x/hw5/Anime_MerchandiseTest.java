package com.example.a009x.hw5;

import android.content.Context;

import org.junit.Before;
import org.junit.Test;
import org.junit.runner.RunWith;
import org.robolectric.RobolectricTestRunner;
import org.robolectric.RuntimeEnvironment;

import static org.hamcrest.CoreMatchers.is;
import static org.hamcrest.CoreMatchers.not;
import static org.junit.Assert.*;



@RunWith(RobolectricTestRunner.class)
public class Anime_MerchandiseTest {


    Anime_Merchandise merch;
    Anime_Merchandise defaultMerch;

    Context context;

    @Before
    public void setUp(){
        this.merch = new Anime_Merchandise("Movie", "used");
        context = RuntimeEnvironment.application.getApplicationContext();
        this.defaultMerch = new Anime_Merchandise(context);
    }

    @Test
    public void costTest() {
        String mcost = merch.cost();
        assertThat(mcost, is("9"));

        String mcost2 = merch.cost();
        assertThat(mcost2, is(not("19")));

    }

    @Test
    public void defaultCostTest(){
        String dmcost = defaultMerch.cost();
        assertThat(dmcost, is("19"));

        String dmcost2 = defaultMerch.cost();
        assertThat(dmcost2, is(not("50")));
    }
}