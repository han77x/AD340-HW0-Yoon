package com.example.a009x.hw5;

import android.content.Context;

public class Anime_Merchandise {

    private String type;
    private String condition;

    public Anime_Merchandise(String type, String condition) {
        this.type = type;
        this.condition = condition;
    }

    public Anime_Merchandise(Context context) {
        this.type = "AnimeDVD";
        this.condition = "new";
    }

    public String getType() {
        return type;
    }

    public void setType(String type) {
        this.type = type;
    }

    public String getCondition() {
        return condition;
    }

    public void setCondition(String condition) {
        this.condition = condition;
    }

    public String cost(){
        int cost = 0;
        if(type.equals("AnimeDVD")){
            if (condition.equals("new")) cost = 19;
            else cost = 9;
        }else if(type.equals("Figurine")){
            if (condition.equals("new")) cost = 100;
            else cost = 50;
        }

        return String.valueOf(cost);

    }
}
