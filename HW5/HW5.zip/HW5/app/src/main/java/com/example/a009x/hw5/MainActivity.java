package com.example.a009x.hw5;
import android.annotation.SuppressLint;
import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.view.View;
import android.widget.AdapterView;
import android.widget.ArrayAdapter;
import android.widget.Button;
import android.widget.EditText;
import android.widget.RadioButton;
import android.widget.RadioGroup;
import android.widget.Spinner;
import android.widget.TextView;
import android.widget.Toast;

public class MainActivity extends AppCompatActivity implements View.OnClickListener {

    private String[] array = new String[]{"AnimeDVD","Figurine"};
    private Button button;
    private TextView textView;
    private RadioGroup radioGroup;
    private RadioButton checkedRadioButton;
    private String condition;
    private String type;
    private Spinner spinner;
    private EditText editText;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);

        ArrayAdapter<String> adapter = new ArrayAdapter<>(this, android.R.layout.simple_spinner_item, array);

        adapter.setDropDownViewResource(android.R.layout.simple_spinner_dropdown_item);
        spinner = findViewById(R.id.spinner);
        spinner.setAdapter(adapter);

        button = findViewById(R.id.button);
        button.setOnClickListener(this);

        textView = findViewById(R.id.display);

        radioGroup = findViewById(R.id.radio_group);
        radioGroup.setOnCheckedChangeListener(new RadioGroup.OnCheckedChangeListener()
        {
            @Override
            public void onCheckedChanged(RadioGroup group, int checkedId) {
                // checkedId is the RadioButton selected

                checkedRadioButton = findViewById(checkedId);
                condition = checkedRadioButton.getText().toString();

            }
        });


        spinner.setOnItemSelectedListener(new AdapterView.OnItemSelectedListener() {

            @Override
            public void onItemSelected(AdapterView<?> arg0, View arg1, int position, long arg3) {
                type = array[position];
            }

            @Override
            public void onNothingSelected(AdapterView<?> arg0) {

            }
        });


    }


    @SuppressLint("SetTextI18n")
    @Override
    public void onClick(View v) {



        try {
            Anime_Merchandise anime_merchandise = new Anime_Merchandise(type, condition);

            TextView textView = findViewById(R.id.display);
            textView.setText(anime_merchandise.cost());
        } catch (NumberFormatException e) {
            Toast.makeText(getApplicationContext(), "Check your inputs", Toast.LENGTH_SHORT).show();
        }

    }


}
